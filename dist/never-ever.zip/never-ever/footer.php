
      <div id="wrap-footer" class="wrap-footer">
        <footer id="colophon" class="site-footer">
          <div class="grid-middle">
            <div class="col-8_sm-12">
            </div>
            <div class="col-4_sm-12">
              <div class="social-wrap">
                <span class="footer-text">Follow Us : </span>
                <ul class="social-list">
                  <li><a href="//www.linkedin.com/company/18277620/com" target="blank"><img src="<?php bloginfo('template_directory'); ?>/imgs/icons/linkedin.svg"></a></li>
                  <li><a href="//www.google.com/url?q=https%3A%2F%2Ftwitter.com%2FBlack_Box_Inc&sa=D&sntz=1&usg=AFQjCNH7z82U3a6Je6f4z8d1pxEdXnlYiA" target="blank"><img src="<?php bloginfo('template_directory'); ?>/imgs/icons/twitter.svg"></a></li>
                  <li><a href="//www.facebook.com/Blackbox-Inc-345506812577356" target="blank"><img src="<?php bloginfo('template_directory'); ?>/imgs/icons/facebook.svg"></a></li>
                </ul>
              </div>
            </div>
          </div>

        </footer>
      </div>
  <?php wp_footer(); ?>
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-107982533-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-107982533-1');
</script>

  </body>
</html>
