<?php // ==== CONFIGURATION (DEFAULT) ==== //

// Specify default configuration values here; these may be overwritten by previously defined values in `functions-config.php`

// Switch for WP AJAX Page Loader; true/false
defined( 'never_ever_SCRIPTS_PAGELOAD' )       || define( 'never_ever_SCRIPTS_PAGELOAD', true );
