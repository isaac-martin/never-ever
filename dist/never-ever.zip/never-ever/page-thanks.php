<?php get_header(); ?>
<div id="wrap-content" class="wrap-content">
  <div id="content" class="site-content">
    <section id="primary" class="content-area">
  <main id="contact-thx" class="site-main">
    <div class="inner-container">
      <div class="grid-middle nearly-full-height">
        <div class="col-12 border conf-msg center">
          <h3 class="conf-head"><img src="<?php bloginfo('template_directory'); ?>/imgs/icons/tick.svg" class="tick" />Thanks for contacting us!</h3>
          <p class="conf-sub">We’ll be in touch very soon.</p>
          <a class="home-btn" href="<?php echo get_bloginfo('url') ?>">Back To Home</a>
        </div>
      </div>
    </div>
  </main>
</section>
</div>
</div>
<?php get_footer(); ?>
